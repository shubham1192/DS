const express = require("express");
const bodyParse = require("body-parser");
const mongoose= require('mongoose');
const read = require("body-parser/lib/read");
mongoose.connect('mongodb://localhost:27017/dsDB', {useNewUrlParser: true});
const _ = require("lodash");
const app = express();

app.use(bodyParse.urlencoded({extended:true}));
app.use(express.static("public"));
app.use(express.static(__dirname));
app.set("view engine", "ejs")
const deviceSchema={
    dname:String
}
const Device=mongoose.model("Device",deviceSchema)

const userSchema={
    uname:String,
    pass:String,
    udevices:[deviceSchema]
}
const User=mongoose.model("User",userSchema)

const dataSchema={
    input:String,
    time:String
}
const Data=mongoose.model("Data",dataSchema)
let username
let password

app.get("/",function(req,res)
{
    res.render("login")
})
app.post("/reg",function(req,res)
{
    username=req.body.user
    password=req.body.pas
    User.findOne({uname:username},function(err,foundUser)
    {
        if(!err)
        {
            if(!foundUser)
            {
                const user=new User({
                    uname:username,
                    pass:password
                });
                user.save();
                res.redirect("/dsdash/"+username)
            }
            else
            {
                User.findOne({uname:username},function(err,foundUser)
                {
                    if(!err)
                    {
                        if(foundUser.pass==password)
                        {
                            res.redirect("/dsdash/"+username)
                        }
                    }
                })
            }
        }
    })
})

app.get("/dsdash/:username",function(req,res)
{
   const {username} = req.params;
   User.findOne({uname:username},function(err,found){
    if(!err)
    {
        if(found)
        {
            res.render("home",{user:username
            ,newDevices:found.udevices})    
        }
    }
   })
   
})

app.post("/",function(req,res)
{
    const devicename=req.body.deviceName
    const username=req.body.user
    const device=new Device({
        dname:devicename
    });
    User.findOne({uname:username},function(err,foundUser)
    {
        if(!err)
        {
            if(foundUser){
                foundUser.udevices.push(device)
                foundUser.save()
            }
        }
        res.redirect("/dsdash/"+username)
    })
})
app.post("/data",function(req,res)
{
    res.redirect("/dummydata")
})
app.get("/dummydata",function(req,res)
{
    Data.find({},function(err,found)
    {
        if(!err)
        {
            if(found)
            {
                console.log(found)
                res.render("dummy",{livedata:found})
            }
        }
    })
})
app.listen(3000, function(err)
{
    console.log("Server up")
})