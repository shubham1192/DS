let mqtt = require('mqtt')
const mongoose= require('mongoose');
mongoose.connect('mongodb://localhost:27017/dsDB', {useNewUrlParser: true});

const dataSchema={
    input:String,
    time:String
}
const Data=mongoose.model("Data",dataSchema)

let options = {
    host: 'test.mosquitto.org',
    port: 1883,
    protocol: 'mqtt',
    username: '',
    password: ''
}

// Initialize the MQTT client
let client = mqtt.connect(options);

// Setup the callbacks
client.on('connect', () => console.log('Connected'));

client.on('error', (error) => console.log(error));

// Called each time a message is received


client.on('message', (topic, message) => {
    console.log("Success")
  console.log('Received message:', topic, message.toString())
  const dt=new Date()
  const data=new Data({
    input:message.toString(),
    time:dt.toUTCString()
});
data.save();
});

// subscribe to topic 'pot/adc/1'
client.subscribe('DSKTK2_TOPIC');